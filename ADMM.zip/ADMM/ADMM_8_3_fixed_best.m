%% ============================================================
%  大规模平面稀疏阵列设计（ADMM + CVX 实现框架）ADMM——8——3
%ADMM_best程序加入其他旁瓣的比较
%修改后的程序改2
% =============================================================
%思路是可以修改目标方向图的形状
%三个程序的参数应保持一致
%==============================================================
%  gemini修正内容：ADMM变量差值累加、量级归一化、更新步长
%gemini再改：移除CVX改用解析解、修正梯度方向、增加数值保护
%  gemini再改：先固定位置优化权重(Warm Start)，再联合优化
%gemini改5
%修改后最好的版本
% =============================================================
clc; clear; close all;
tic; % 启动计时器
%% 参数设置 
lambda = 1;         % 波长
k = 2*pi/lambda;    % 波数 
d_min = 0.5 * lambda; % 最小阵元间距
d_max = 5.0 * lambda; % 最大阵元间距范围
L_iter = 50;        % ADMM 总迭代次数
% ADMM 参数
rho = 1.0;          % 惩罚因子
gamma = 0.1;        % 稀疏正则化参数 
epsilon = 1e-3;     % 重加权分母防止除零 
% 位置更新参数
step_size_pos = 0.001; 
eta = 10;           % 距离惩罚项的权重 
%% 目标方向图与网格设置 
P_grid = 180; Q_grid = 180; % 网格点数量 
% 俯仰角 Theta: 0 到 180 度 (P_grid+1 个点)
theta_deg = linspace(0, 180, P_grid+1);
% 方位角 Phi: 0 到 180 度 (Q_grid+1 个点)
fhi_deg = linspace(0, 180, Q_grid+1);
theta_rad = deg2rad(theta_deg);
fhi_rad = deg2rad(fhi_deg);
% 构建二维角度网格，并展平为向量
[FHI_GRID, THETA_GRID] = meshgrid(fhi_rad, theta_rad); 
THETA_VEC = THETA_GRID(:);
FHI_VEC = FHI_GRID(:);
M = numel(THETA_GRID);  % 总网格点数 M
% 计算 u/v 向量（M x 1）
U = sin(THETA_VEC) .* cos(FHI_VEC);
V = sin(THETA_VEC) .* sin(FHI_VEC);
% =========================================================
%% 目标方向图
% =========================================================
theta0_deg = 90; fhi0_deg = 90; % 目标中心角
% 目标中心对应的 u/v 值
u0 = sin(deg2rad(theta0_deg)) * cos(deg2rad(fhi0_deg));
v0 = sin(deg2rad(theta0_deg)) * sin(deg2rad(fhi0_deg));

%角域中设定目标方向图
% 目标宽度：在 u/v 域的欧氏距离
target_u_v_width = 0.1; 
B = zeros(M, 1);    % 初始化目标向量 M x 1
% 构建 Mask
dist_from_main = sqrt((U - u0).^2 + (V - v0).^2);
main_lobe_idx = dist_from_main <= target_u_v_width;
B(main_lobe_idx) = 1; % 主瓣区域置为 1
%%  初始化阵元位置
% N=400 对应了20x20的均匀阵列
Grid_Size = 20; 
N = Grid_Size * Grid_Size; % N = 400
Spacing = d_min;% 初始阵元间距
coords_1D = linspace(-(Grid_Size)/2 * Spacing, (Grid_Size)/2 * Spacing, Grid_Size+1);
[X_GRID, Y_GRID] = meshgrid(coords_1D, coords_1D);
x_n = X_GRID(:);
y_n = Y_GRID(:);
N=length(x_n);
% 初始化 ADMM 变量
w = ones(N, 1);      % 权重 w 
s = w;               % 辅助变量 s 
u_dual = zeros(N, 1);% 对偶变量 u 
%% ADMM 主循环
A = ones(M, N); 
% 移除 W_save, xn_save, yn_save 的存储
fit_errors = zeros(L_iter, 1);
sparsity_counts = zeros(L_iter, 1); % 激活阵元数
for iter = 1:L_iter
    
    % 阵列因子构建（不带权重）
    Phase_Term = U * x_n' + V * y_n'; % M x N 矩阵
    A = exp(1j * k * Phase_Term); 
    
    % --- 子问题 1: 更新权重 w (使用 CVX) ---
    % min ||B - A*w||^2 + (rho/2) * ||w - s + u_dual||^2
    cvx_begin quiet
        variable w_new(N) 
       
        e_residue = B - A * w_new;
        term1 = e_residue' * e_residue; %  ||B - A*w||^2
        
        e_admm = w_new - s + u_dual;
        term2 = (rho / 2) * (e_admm' * e_admm); %  ||w - s + u_dual||^2
        
        minimize( term1 + term2 )
    cvx_end
    
    w = w_new;
    
    % --- 子问题 2: 更新稀疏变量 s (重加权 L1) （有解析解） ---
    g_weights = 1 ./ (abs(s) + epsilon); 
    v_temp = w + u_dual;
    threshold = (gamma .* g_weights) / rho;
    
    % 解析解为软阈值算子
    s_abs=abs(v_temp);
    s_sign=v_temp ./ s_abs;
    % 修正 NaN 警告
    s_sign(isnan(s_abs)) = 0; 
    s = s_sign .* max(s_abs - threshold, 0);
    
    % --- 步骤 3: 更新对偶变量 u  ---
    u_dual = u_dual + (w - s);
    
    % --- 子问题 3: 更新阵元位置 (梯度下降)  ---
    
    % 计算残差向量 e
    e = A * w - B; % M x 1
    
    %  计算关于位置的梯度 
    grad_x = zeros(N, 1);
    grad_y = zeros(N, 1);
    
    for n = 1:N
        A_n = A(:, n); % M x 1
        
        % 梯度计算公式： d/dx ||Aw-B||^2 = 2 Re{ e' * (dA/dx * w) }
        % dA_n/dx = j*k*u * A_n
        % 注意：这里是原代码的梯度计算方式，与解析解版本中的修正不同。
        % 若要确保收敛，应使用修正后的梯度。
        sum_term_x = (e') * (U .* A_n); 
        grad_x(n) = 2 * real(1j * k * w(n) * sum_term_x);
        
        sum_term_y = (e') * (V .* A_n);
        grad_y(n) = 2 * real(1j * k * w(n) * sum_term_y);
    end
    
    % 添加距离约束的惩罚项梯度 (简化的排斥力) 
    grad_dist_x = zeros(N, 1);
    grad_dist_y = zeros(N, 1);
    
    for i = 1:N
        for j = 1:N
            if i == j, continue; end
            dist_sq = (x_n(i)-x_n(j))^2 + (y_n(i)-y_n(j))^2;
            dist = sqrt(dist_sq);
            
            if dist < d_min
                force = -1 * (d_min - dist); % 线性排斥力大小
                dir_x = (x_n(i) - x_n(j)) / dist;
                dir_y = (y_n(i) - y_n(j)) / dist;
                
                grad_dist_x(i) = grad_dist_x(i) + force * dir_x;
                grad_dist_y(i) = grad_dist_y(i) + force * dir_y;
            end
        end
    end
    
    % 更新坐标
    x_n = x_n - step_size_pos * (grad_x + eta * grad_dist_x);
    y_n = y_n - step_size_pos * (grad_y + eta * grad_dist_y);
    
    % --- 打印进度 ---
    fit_error = norm(A*w - B)^2;
    sparsity_count = sum(abs(w) > 1e-2); 
    fprintf('Iter %d: Error = %.4f, Sparsity (Non-zero w) = %d\n', iter, fit_error, sparsity_count);
%储存变量
fit_errors(iter) = fit_error;
sparsity_counts(iter) = sparsity_count;
end
%%  结果可视化
figure('Position', [100, 100, 1200, 500]);

% 1. 阵元分布图
subplot(1,3,1);
active_idx = find(abs(w) > 1e-2);
scatter(x_n(active_idx), y_n(active_idx), 36, abs(w(active_idx)), 'filled');
title(sprintf('优化后的阵元分布 (N=%d)', length(active_idx)));
xlabel('x (\lambda)'); ylabel('y (\lambda)');
axis equal; colorbar;

% 2. 方向图
subplot(1,3,2);
% 重建最终方向图，并转换为 dB
AF_final = A * w;
AF_final_2D = reshape(abs(AF_final), P_grid+1, Q_grid+1);
AF_db = 20*log10(AF_final_2D / max(AF_final_2D(:)));
% 使用角度作为坐标轴
imagesc(fhi_deg, theta_deg, AF_db);
set(gca,'YDir','normal') % 修正图像方向
caxis([-40, 0]); % 显示动态范围
title('优化后的方向图 (dB)');
xlabel('\phi (方位角) [Deg]'); ylabel('\theta (俯仰角) [Deg]');
colorbar;

% 3. 迭代收敛过程
subplot(1,3,3);
yyaxis left;
plot(1:L_iter, fit_errors, 'LineWidth', 2, 'Color', 'b');
ylabel('拟合误差 ');
yyaxis right;
plot(1:L_iter, sparsity_counts, 'LineWidth', 2, 'Color', 'r', 'LineStyle', '--');
ylabel('激活阵元数');
title('ADMM 收敛过程');
xlabel('迭代次数');
grid on;

%% 添加切片功能
figure;
% 假设目标在 theta0_deg = 90 度
theta_slice_deg = theta0_deg; 

% 找到最接近 90 度的行索引
[~, row_idx] = min(abs(theta_deg - theta_slice_deg));

%1. 取出当前俯仰角的方位切片（你已有）
AF_slice_db = AF_db(row_idx, :);          % 已经做完归一化，主瓣峰值 0 dB

% 2. 找所有局部峰值（旁瓣峰值）
%    参数说明：'MinPeakProminence',4 表示峰值至少要高出左右“谷”4 dB 以上才算，
%    可有效抑制噪声毛刺；可按需要调大或调小。
[pkVal, pkLoc] = findpeaks(AF_slice_db, fhi_deg, ...
                           'MinPeakHeight', -50, ...   % 只关心 -50 dB 以上
                           'MinPeakDistance', 2, ...   % 角度上至少隔 2°
                           'MinPeakProminence', 4);    %  prominence 门槛

% 3. 去掉主瓣峰值（0 dB 附近那个）——简单办法：去掉 > -1 dB 的峰值
isMainLobe = pkVal > -1;
pkVal(isMainLobe) = [];
pkLoc(isMainLobe) = [];

% 4. 旁瓣最高峰值
[sll_max, idxMax] = max(pkVal);     % 全局最高旁瓣
sll_phi   = pkLoc(idxMax);          % 对应方位角

% 5. 画图
plot(fhi_deg, AF_slice_db, 'LineWidth', 2);
hold on;
yline(sll_max, 'r--', ...
      sprintf('SLL: %.2f dB \\phi=%.1f\\circ)', sll_max, sll_phi));

ylim([-50 5]);
xlim([min(fhi_deg) max(fhi_deg)]);
grid on;
title(sprintf('方向图切片 (\\theta = %.1f\\circ)', theta_deg(row_idx)));
xlabel('\phi (方位角) [Deg]');
ylabel('幅度 (dB)');

%% 显示全程序用时
elapsedTime = toc; % 停止计时器
fprintf('程序运行总用时: %.4f 秒\n', elapsedTime);