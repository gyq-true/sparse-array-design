%% ============================================================
%8.2减去阵元的变动的消融实验
%ADMM_8_2_fixed更改3
%rho=0.5,gamma=0.5
%s的更新中用w代替s减少震荡
%gamma=2
%cvx中阵元数目的比重调整alpha*term1+beta*term2
% =============================================================
%思路
%==============================================================
clc; clear; close all;
tic; % 启动计时器
%% 参数设置 
lambda = 1;         % 波长
k = 2*pi/lambda;    % 波数 
d_min = 0.5 * lambda; % 最小阵元间距
d_max = 5.0 * lambda; % 最大阵元间距范围
L_iter = 50;        % ADMM 总迭代次数
%cvx
alpha=0.3;
beta=0.7;
% ADMM 参数
rho = 0.5;          % 惩罚因子
gamma = 2;        % 稀疏正则化参数 
epsilon = 1e-6;     % 重加权分母防止除零 
% 位置更新参数
step_size_pos = 0.0001; 
eta = 10;           % 距离惩罚项的权重 
%% 目标方向图与网格设置 
P_grid = 180; Q_grid = 180; % 网格点数量 
% 俯仰角 Theta: 0 到 180 度 (P_grid+1 个点)
theta_deg = linspace(0, 180, P_grid+1);
% 方位角 Phi: 0 到 180 度 (Q_grid+1 个点)
fhi_deg = linspace(0, 180, Q_grid+1);
theta_rad = deg2rad(theta_deg);
fhi_rad = deg2rad(fhi_deg);
% 构建二维角度网格，并展平为向量
[FHI_GRID, THETA_GRID] = meshgrid(fhi_rad, theta_rad); 
THETA_VEC = THETA_GRID(:);%矩阵按列存储，此处按列展开
FHI_VEC = FHI_GRID(:);
M = numel(THETA_GRID);  % 总网格点数 M
% 计算 u/v 向量（M x 1）
U = sin(THETA_VEC) .* cos(FHI_VEC);
V = sin(THETA_VEC) .* sin(FHI_VEC);
% =========================================================
% 目标方向图
% =========================================================
theta0_deg = 90; fhi0_deg = 90; % 目标中心角
% 目标中心对应的 u/v 值
u0 = sin(deg2rad(theta0_deg)) * cos(deg2rad(fhi0_deg));
v0 = sin(deg2rad(theta0_deg)) * sin(deg2rad(fhi0_deg));
%% 
% 空域设定目标方向图
% theta0= 90;fhi0=90;
% target_width = 5; % 设定的主瓣宽度为周围9*9个网格
% B = zeros(length(theta_deg),length(fhi_deg));    % 初始化目标向量
% B(theta0-4:theta0+4,fhi0-4:fhi0+4)=1;
% B=B(:);
% 
% fprintf('目标主瓣网格点数量: %d / %d\n', sum(B), M);
%% 
%角域中设定目标方向图
% 目标宽度：在 u/v 域的欧氏距离
target_u_v_width = 0.1; 
B = zeros(M, 1);    % 初始化目标向量 M x 1
% 构建 Mask
dist_from_main = sqrt((U - u0).^2 + (V - v0).^2);
main_lobe_idx = dist_from_main <= target_u_v_width;
B(main_lobe_idx) = 1; % 主瓣区域置为 1
%%  初始化阵元位置
% N=400 对应了20x20的均匀阵列
Grid_Size = 20; 
N = Grid_Size * Grid_Size; % N = 400
Spacing = d_min;% 初始阵元间距
coords_1D = linspace(-(Grid_Size)/2 * Spacing, (Grid_Size)/2 * Spacing, Grid_Size+1);
[X_GRID, Y_GRID] = meshgrid(coords_1D, coords_1D);
x_n = X_GRID(:);
y_n = Y_GRID(:);
N=length(x_n);
% 初始化 ADMM 变量
w = complex(ones(N, 1));      % 权重 w 
s = w;               % 辅助变量 s 
u_dual = complex(zeros(N, 1));% 对偶变量 u 
%% ADMM 主循环
A = ones(M, N); 
fit_errors = zeros(L_iter, 1);
sparsity_counts = zeros(L_iter, 1); % 激活阵元数
u_resident=zeros(L_iter, 1);
%阵列方向图初始化
Phase_Term = U * x_n' + V * y_n'; % M x N 矩阵
A = exp(1j * k * Phase_Term); 
for iter = 1:L_iter
    
   
    % --- 子问题 1: 更新权重 w (使用 CVX) ---
    % min ||B - A*w||^2 + (rho/2) * ||w - s + u_dual||^2
    cvx_begin quiet
        variable w_new(N) complex
       
        e_residue = B - A * w_new;
        term1 = e_residue' * e_residue; %  ||B - A*w||^2
        
        e_admm = w_new - s + u_dual;
        term2 = (rho / 2) * (e_admm' * e_admm); %  ||w - s + u_dual||^2
        
        minimize( alpha*term1 + beta*term2 )
    cvx_end
    
    w = w_new;
    
    % --- 子问题 2: 更新稀疏变量 s (重加权 L1) （有解析解） ---
    g_weights = 1 ./ (abs(w) + epsilon); 
    v_temp = w + u_dual;
    threshold = (gamma .* g_weights) / rho;
    
    % 解析解为软阈值算子
    s_abs=abs(v_temp);
    s_sign=v_temp ./ (s_abs+1e-10);
    
    s = s_sign .* max(s_abs - threshold, 0);
    
    % --- 步骤 3: 更新对偶变量 u  ---
    u_dual = w - s;
    
  
    
    % --- 打印进度 ---
    fit_error = norm(A*w - B)^2;
    sparsity_count = sum(abs(w) > 1e-2); 
    u_resident=norm(u_dual);
    fprintf('Iter %d: Error = %.4f, Sparsity (Non-zero w) = %d,||u||=%.4f\n', iter, fit_error, sparsity_count,u_resident);
%储存变量
fit_errors(iter) = fit_error;
sparsity_counts(iter) = sparsity_count;
u_residents(iter)=u_resident;
end
%%  结果可视化
figure;
% 阵元分布图
subplot(1,2,1);
active_idx = find(abs(w) > 1e-2);
scatter(x_n(active_idx), y_n(active_idx), 36, abs(w(active_idx)), 'filled');
title(sprintf('优化后的阵元分布 (N=%d)', length(active_idx)));
xlabel('x (\lambda)'); ylabel('y (\lambda)');
axis equal; colorbar;
%  方向图
subplot(1,2,2);
% 重建最终方向图，并转换为 dB
AF_final = A * w;
AF_final_2D = reshape(abs(AF_final), P_grid+1, Q_grid+1);
AF_db = 20*log10(AF_final_2D / max(AF_final_2D(:)));
% 使用角度作为坐标轴
imagesc(fhi_deg, theta_deg, AF_db);
set(gca,'YDir','normal') % 修正图像方向
caxis([-40, 0]); % 显示动态范围
title('优化后的方向图 (dB)');
xlabel('\phi (方位角) [Deg]'); ylabel('\theta (俯仰角) [Deg]');
colorbar;
%% 迭代收敛过程
figure;
hold on;

% 绘制三条曲线，使用不同的样式区分
p1 = plot(1:L_iter, fit_errors, 'b-', 'LineWidth', 2, 'DisplayName', '方向图拟合误差');
p2 = plot(1:L_iter, sparsity_counts, 'r--', 'LineWidth', 2, 'DisplayName', '激活阵元数');
p3 = plot(1:L_iter, u_residents, 'g:', 'LineWidth', 2, 'DisplayName', '累计ADMM变量拟合误差（理想情况为0）');

% 设置图形属性
title('ADMM 收敛过程');
xlabel('迭代次数');
grid on;

% 添加图例
legend([p1, p2, p3], 'Location', 'best');

% 隐藏坐标轴（但保留网格）
ax = gca;
ax.XAxis.Visible = 'off';  % 隐藏x轴线和刻度
ax.YAxis.Visible = 'off';  % 隐藏y轴线和刻度

hold off;

%% 显示全程序用时
elapsedTime = toc; % 停止计时器
fprintf('程序运行总用时: %.4f 秒\n', elapsedTime);