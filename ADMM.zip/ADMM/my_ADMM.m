%% ============================================================
%  大规模平面稀疏阵列设计（256×256），ADMM + CVX 实现框架
%  先使用小规模阵列查看效果再设置为256*256的大规模阵列
%  整个程序需要加入可视化
% =============================================================

clc; clear; close all;
tic; % 启动计时器

%% 参数设置 
N = 400;             % 阵元总数 (初始)
lambda = 1;         % 波长
k = 2*pi/lambda;    % 波数 
d_min = 0.5 * lambda; % 最小阵元间距
d_max = 5.0 * lambda; % 最大阵元间距范围
L_iter = 50;        % ADMM 总迭代次数
%%
% ADMM 参数
rho = 1.0;          % 惩罚因子
gamma = 1;        % 稀疏正则化参数 
epsilon = 1e-3;     % 重加权分母防止除零 
beta=50;            %cvx中施加的权重

% 位置更新步长
step_size_pos = 0.0001; 
eta = 10;           % 距离惩罚项的权重 
alpha_merit = 0.5;  %指标平衡因子
eps=1e-6;%小的常数

%%  目标方向图与网格设置 
%  空域180*180
% 离散化空域
P = 180; Q = 180;     % 网格点数量 
theta= linspace(0, 180, P+1);
fhi= linspace(0, 180, Q+1);
theta_rad=deg2rad(theta);
fhi_rad=deg2rad(fhi);
M =length(theta)*length(fhi);  % 总网格点数 

%% 初始化变量
% 随机初始化阵元位置 (x, y)
Spacing = d_min;%初始阵元间距
x=linspace(0,sqrt(N),sqrt(N)+1);%横坐标阵元排列
y=linspace(0,sqrt(N),sqrt(N)+1);%纵坐标阵元排列
xn=x*Spacing;
yn=y*Spacing;
[X_GRID, Y_GRID] = meshgrid(xn, yn);
% 将阵元位置展平为 N x 1 的向量，此时每个阵元横纵通过索引对应
x_n = X_GRID(:);
y_n = Y_GRID(:);
N=length(x_n);%更新数目

%% 
% 初始化 ADMM 变量
w = ones(N, 1);      % 权重 w 
s = w;               % 对偶变量 s 
u_dual = zeros(N, 1);% 残差变量 u (u=w-s)


[THETA,FHI]=meshgrid(theta_rad,fhi_rad);
u_axis=sin(THETA).*cos(FHI);
v_axis=sin(THETA).*sin(FHI);
U=u_axis(:);
V=v_axis(:);

%% 定义目标方向图
theta0= 90;fhi0=90;
u0=sin(deg2rad(theta0))*cos(deg2rad(fhi0));
v0=sin(deg2rad(theta0))*sin(deg2rad(fhi0));
% 定义目标方向图 B(theta,fhi),假设主瓣指向90,90
target_u_v_width = 0.1; 
B = zeros(M, 1);    % 初始化目标向量 M x 1
% 构建 Mask
dist_from_main = sqrt((U - u0).^2 + (V - v0).^2);
main_lobe_idx = dist_from_main <= target_u_v_width;
B(main_lobe_idx) = 1; % 主瓣区域置为 1
%% %% ADMM 主循环
A=ones(M,N);%阵列因子初始化
W_save=zeros(L_iter,N);
xn_save=zeros(L_iter,length(x_n));
yn_save=zeros(L_iter,length(y_n));
fit_errors = zeros(L_iter, 1);
sparsity_counts = zeros(L_iter, 1); % 激活阵元数
for iter = 1:L_iter%ADMM循环
    %优化参数为w，x_n，y_n
    % A循环完后的维度: M ，当前切片维度M*N
    A=exp(1j * k * (U* x_n' + V * y_n'));%%AF(theta,fhi)阵列因子
    %优化问题为最小化(B - A).^2+gamma||w||1(最大最小距离约束)
    % --- 子问题 1: 更新权重 w (使用 CVX) ---
    % min ||B - A*w||^2 + (rho/2) * ||w - s + u_dual||^2
    cvx_begin quiet
        variable w_new(N) complex
        expression term1
        expression term2
        e_residue=B - A * w_new;
        e_admm = w_new - s + u_dual;
        term1 = beta * e_residue'*e_residue; % 数据拟合项
        term2 = (rho / 2) * (e_admm' * e_admm); % ADMM 耦合项
        minimize( term1 + term2 )
    cvx_end
    w = w_new;
    % --- 子问题 2: 更新稀疏变量 s (重加权 L1)  ---
    % min gamma * ||W_g * s||_1 + (rho/2) * ||w - s + u_dual||^2
    % 这里的 g 是重加权系数
    g_weights = 1 ./ (abs(s) + epsilon); % 
    
    % 这是一个加权软阈值问题 (Weighted Soft Thresholding)
    % 解析解为: prox(v) = sign(v) * max(|v| - lambda/rho * g, 0)
    v_temp = w + u_dual;
    threshold = (gamma .* g_weights) / rho;
    s_abs=abs(v_temp);
    s_sign=v_temp ./ s_abs;
    s_sign(isnan(s_abs)) = 0; 
    s = s_sign .* max(s_abs - threshold, 0);
    
    
    % --- 步骤 3: 更新对偶变量 u  ---
    % 标准 ADMM 更新: u = u + (w - s)
    u_dual = u_dual + (w - s);
    
    % --- 子问题 3: 更新阵元位置 (梯度下降)  ---
    % 目标函数: Phi(r) = ||B - A(r)w||^2 + eta * P_dist(r)
    
    % 1. 计算残差向量 e
    e = A * w - B;
    
%     % 2. 计算关于位置的梯度 
%     % d/dx_n = 2 * Re{ jk * w_n * sum(e_t' * u_p * A_tn) }
%     grad_x = zeros(N, 1);
%     grad_y = zeros(N, 1);
%     
%     for n = 1:N
%         % 提取 A 的第 n 列 (A_tn)
%         A_n = A(:, n); 
%         
%         % 梯度计算公式
%         % sum_term_x = sum( conj(e) .* U .* A_n )
%         sum_term_x =conj(e) .* (U .* A_n); 
%         grad_x(n) = 2 * real(1j * k * w(n) * sum_term_x);
%         
%         % sum_term_y = sum( conj(e) .* V.* A_n )
%         sum_term_y = conj(e) .* (V .* A_n);
%         grad_y(n) = 2 * real(1j * k * w(n) * sum_term_y);
%     end
    
    %% % 2. 向量化计算关于位置的梯度
    % 梯度计算的核心部分： sum_t(e_t' * u_p * A_tn)
    % 可以通过矩阵乘法实现： (U .* conj(e)).' * A 
    % 或者更简单： A.' * (U .* conj(e)) (因为 A_n 是 A 的一列，A_n^T 是 A^T 的一行)
    
    grad_x_resident = zeros(N, 1);
    grad_y_resident = zeros(N, 1);
    % (U .* conj(e)) 是一个 M x 1 向量，记为 C_u
    C_u = U .* conj(e); 
    C_v = V .* conj(e);
    
    % M x N 矩阵 A 的转置是 N x M
    % N x M 矩阵 (A.') 乘以 M x 1 向量 C_u 得到 N x 1 向量，即所有 n 的 sum_term_x
    
    % 计算所有 n 的 sum_term_x
    sum_terms_x = A.' * C_u; % N x 1 向量
    % 计算所有 n 的 sum_term_y
    sum_terms_y = A.' * C_v; % N x 1 向量
    
    % 最终梯度 (使用元素级乘法 .* )
    % w 是 N x 1 向量，sum_terms_x/y 也是 N x 1 向量
    grad_x_resident = 2 *beta* real(1j * k * w .* sum_terms_x); % N x 1
    grad_y_resident = 2 *beta* real(1j * k * w .* sum_terms_y); % N x 1
    %% 

    % 3. 添加距离约束的惩罚项梯度 (简化的排斥力) 
    %FHI_R=(e'*e)+ eta * P_dist(r)
%     % 如果距离小于 d_min，产生推力
%     grad_dist_x = zeros(N, 1);
%     grad_dist_y = zeros(N, 1);
%     
%     for i = 1:N
%         for j = 1:N
%             if i == j, continue; end
%             dist_sq = (x_n(i)-x_n(j))^2 + (y_n(i)-y_n(j))^2;
%             dist = sqrt(dist_sq);
%             
%             if dist < d_min
%                 % 简单的倒数排斥力或线性惩罚
%                 force = -1 * (d_min - dist); % 指向远离方向
%                 dir_x = (x_n(i) - x_n(j)) / dist;
%                 dir_y = (y_n(i) - y_n(j)) / dist;
%                 
%                 grad_dist_x(i) = grad_dist_x(i) + force * dir_x;
%                 grad_dist_y(i) = grad_dist_y(i) + force * dir_y;
%             end
%         end
%     end
grad_x_dist = zeros(N, 1);
grad_y_dist = zeros(N, 1);
Dist_min=zeros(N,N);
     for i = 1:N
        d_x = x_n(i) - x_n; 
        d_y = y_n(i) - y_n;
        dist = sqrt(d_x.^2 + d_y.^2);
        
        % 找出距离小于 d_min 且不为自身的 j
        repel_idx = (dist < d_min) & (dist > 1e-6); 
        
        if any(repel_idx)
            % 指向远离方向的单位向量: dir_x = (x_i - x_j) / dist
            dir_x = d_x(repel_idx) ./ dist(repel_idx);
            dir_y = d_y(repel_idx) ./ dist(repel_idx);
            
            % 线性惩罚梯度项为 1 (因为 d/d_dist(d_min - dist) = -1)
            % 梯度方向与 (ri - rj) 方向相反 (排斥)
            grad_x_dist(i) = sum( -dir_x ); % 累加排斥力的 x 分量
            grad_y_dist(i) = sum( -dir_y ); % 累加排斥力的 y 分量
        end
     end
    %FHI_R=(e'*e)+ eta * P_dist;
    % 4. 更新坐标
    x_n = x_n - step_size_pos * (grad_x_resident +eta* grad_x_dist);
    y_n = y_n - step_size_pos * (grad_y_resident +eta* grad_y_dist);
    
    % 简单的边界限制 (可选)
    % x_n = max(min(x_n, 10*lambda), -10*lambda);
    % y_n = max(min(y_n, 10*lambda), -10*lambda);
    
    % --- 打印进度 ---
    fit_error = norm(A*w - B)^2;
    sparsity_count = sum(abs(w) > 1e-2);
    fprintf('Iter %d: Error = %.4f, Sparsity (Non-zero w) = %d\n', iter, fit_error, sparsity_count);
%储存迭代变量
W_save(iter,:)=w;
xn_save(iter,:)=x_n;
yn_save(iter,:)=y_n;
fit_errors(iter) = fit_error;
sparsity_counts(iter) = sparsity_count;

end

%% 1.优化后的结果
figure;
%阵元分布
subplot(1,2,1);
active = find(abs(w) > 1e-2);
scatter(x_n(active), y_n(active), 36, abs(w(active)), 'filled');
title('优化后的阵元分布与权重幅度');
xlabel('x (\lambda)'); ylabel('y (\lambda)');
axis equal; colorbar;
% 重建最终方向图
subplot(1,2,2);
A_final_matrix = exp(1j * k * (U * x_n' + V * y_n'));
AF_final_flat = A_final_matrix * w; % M x 1
AF_final = reshape(AF_final_flat, P+1, Q+1); 

AF_db = 20*log10(abs(AF_final) / max(abs(AF_final(:))));
imagesc(theta, fhi, AF_db.'); % 需要转置以正确显示
caxis([-40, 0]); % 显示动态范围
title('优化后的方向图 (dB)');
xlabel('方向角'); ylabel('俯仰角');
colorbar;
%% 2.迭代收敛过程 
figure;
yyaxis left;
plot(1:L_iter, fit_errors, 'LineWidth', 2, 'Color', 'b');
ylabel('拟合误差 ');
yyaxis right;
plot(1:L_iter, sparsity_counts, 'LineWidth', 2, 'Color', 'r', 'LineStyle', '--');
ylabel('激活阵元数');
title('ADMM 收敛过程');
xlabel('迭代次数');
grid on;
%% 显示最好的一次迭代
max_err = max(fit_errors);
min_err = min(fit_errors);
max_sparse = max(sparsity_counts);
min_sparse = min(sparsity_counts);
% 归一化误差 (越小越好)
% eps 是为了防止分母为零
norm_errors = (fit_errors - min_err) / (max_err - min_err + eps); 
% 归一化稀疏度 (激活阵元数越少越好)
norm_sparsity = (sparsity_counts - min_sparse) / (max_sparse - min_sparse + eps);

%F_merit = alpha * (归一化误差) + (1-alpha) * (归一化稀疏度)
merit_function = alpha_merit * norm_errors + (1 - alpha_merit) * norm_sparsity;

[~, best_iter] = min(merit_function);

w_best = W_save(best_iter,:);
x_n_best = xn_save(best_iter,:);
y_n_best = yn_save(best_iter,:);
%显示
figure;
%显示阵元分布
subplot(1,2,1);
active_idx = find(abs(w_best) > 1e-2);
scatter(x_n_best(active_idx), y_n_best(active_idx), 36, abs(w_best(active_idx)), 'filled');
title(sprintf('最优阵元分布N=%d', length(active_idx)));
%显示方向图
subplot(1,2,2);
% 向量化计算 AF_final_flat = A_best * w_best;
A_best_matrix = exp(1j * k * (U * x_n_best + V * y_n_best));
AF_best_flat = A_best_matrix * w_best'; % M x 1
AF_best = reshape(AF_best_flat, P+1, Q+1); 

AF_best_db = 20*log10(abs(AF_best) / max(abs(AF_best(:))));
imagesc(theta, fhi, AF_best_db.'); % 需要转置以正确显示

caxis([-40, 0]); % 显示动态范围
title('优化后的方向图 (dB)');
xlabel('方向角'); ylabel('俯仰角');
colorbar;

%% 显示全程序用时
elapsedTime = toc; % 停止计时器，并将运行时间赋值给变量
fprintf('程序运行总用时: %.4f 秒\n', elapsedTime); % 打印结果