%% ============================================================
%8.2减去阵元的变动的消融实验
%ADMM_8_2_fixed更改4
%rho=0.5,gamma=0.5
%s的更新中用w代替s减少震荡
%gamma=2
%cvx中阵元数目的比重调整alpha*term1+beta*term2
% =============================================================
%ADMM_best直接改，阵元数目改为32,阵元过于稀疏了,且并不收敛
% =============================================================
clc; clear; close all;
tic; % 启动计时器
%% 参数设置 
lambda = 1;         % 波长
k = 2*pi/lambda;    % 波数 
d_min = 0.5 * lambda; % 最小阵元间距 (仅用于初始化)
d_max = 5.0 * lambda; % 最大阵元间距范围
L_iter = 50;        % ADMM 总迭代次数
% ADMM 参数
rho = 1.0;          % 惩罚因子
gamma = 0.1;        % 稀疏正则化参数 
epsilon = 1e-3;     % 重加权分母防止除零 
% 位置更新参数（已废弃，但保留变量以便与原代码结构保持一致）
step_size_pos = 0.001; 
eta = 10;           % 距离惩罚项的权重 
%% 目标方向图与网格设置 
P_grid = 180; Q_grid = 180; % 网格点数量 
% 俯仰角 Theta: 0 到 180 度 (P_grid+1 个点)
theta_deg = linspace(0, 180, P_grid+1);
% 方位角 Phi: 0 到 180 度 (Q_grid+1 个点)
fhi_deg = linspace(0, 180, Q_grid+1);
theta_rad = deg2rad(theta_deg);
fhi_rad = deg2rad(fhi_deg);
% 构建二维角度网格，并展平为向量
[FHI_GRID, THETA_GRID] = meshgrid(fhi_rad, theta_rad); 
THETA_VEC = THETA_GRID(:);
FHI_VEC = FHI_GRID(:);
M = numel(THETA_GRID);  % 总网格点数 M
% 计算 u/v 向量（M x 1）
U = sin(THETA_VEC) .* cos(FHI_VEC);
V = sin(THETA_VEC) .* sin(FHI_VEC);
% =========================================================
% 目标方向图
% =========================================================
theta0_deg = 90; fhi0_deg = 90; % 目标中心角
% 目标中心对应的 u/v 值
u0 = sin(deg2rad(theta0_deg)) * cos(deg2rad(fhi0_deg));
v0 = sin(deg2rad(theta0_deg)) * sin(deg2rad(fhi0_deg));

% 目标宽度：在 u/v 域的欧氏距离
target_u_v_width = 0.1; 
B = zeros(M, 1);    % 初始化目标向量 M x 1
% 构建 Mask
dist_from_main = sqrt((U - u0).^2 + (V - v0).^2);
main_lobe_idx = dist_from_main <= target_u_v_width;
B(main_lobe_idx) = 1; % 主瓣区域置为 1
%%  初始化阵元位置
% N=400 对应了20x20的均匀阵列
Grid_Size = 32; 
N = Grid_Size * Grid_Size; % N = 400
Spacing = d_min;% 初始阵元间距
coords_1D = linspace(-(Grid_Size)/2 * Spacing, (Grid_Size)/2 * Spacing, Grid_Size+1);
[X_GRID, Y_GRID] = meshgrid(coords_1D, coords_1D);
x_n = X_GRID(:);
y_n = Y_GRID(:);
N=length(x_n);
% 初始化 ADMM 变量
w = ones(N, 1);      % 权重 w 
s = w;               % 辅助变量 s 
u_dual = zeros(N, 1);% 对偶变量 u 
%% ADMM 主循环
A = ones(M, N); % 预分配 A
fit_errors = zeros(L_iter, 1);
sparsity_counts = zeros(L_iter, 1); % 激活阵元数
for iter = 1:L_iter
    
    % 阵列因子构建（位置固定，只计算一次即可，但为保持结构，每次迭代都计算）
    Phase_Term = U * x_n' + V * y_n'; % M x N 矩阵
    A = exp(1j * k * Phase_Term); 
    
    % --- 子问题 1: 更新权重 w (使用 CVX) ---
    cvx_begin quiet
        variable w_new(N) 
       
        e_residue = B - A * w_new;
        term1 = e_residue' * e_residue; 
        
        e_admm = w_new - s + u_dual;
        term2 = (rho / 2) * (e_admm' * e_admm); 
        
        minimize( term1 + term2 )
    cvx_end
    
    w = w_new;
    
    % --- 子问题 2: 更新稀疏变量 s (重加权 L1) （有解析解） ---
    g_weights = 1 ./ (abs(s) + epsilon); 
    v_temp = w + u_dual;
    threshold = (gamma .* g_weights) / rho;
    
    s_abs=abs(v_temp);
    s_sign=v_temp ./ s_abs;
    s_sign(isnan(s_abs)) = 0; 
    s = s_sign .* max(s_abs - threshold, 0);
    
    % --- 步骤 3: 更新对偶变量 u  ---
    u_dual = u_dual + (w - s);
    
    % --- 子问题 3: 更新阵元位置 (梯度下降) - 已移除 ---
    % x_n 和 y_n 在此循环中不再更新
    
    % --- 打印进度 ---
    fit_error = norm(A*w - B)^2;
    sparsity_count = sum(abs(w) > 1e-2); 
    fprintf('Iter %d: Error = %.4f, Sparsity (Non-zero w) = %d\n', iter, fit_error, sparsity_count);

fit_errors(iter) = fit_error;
sparsity_counts(iter) = sparsity_count;
end
%%  计算最终方向图结果 (为可视化准备)
AF_final = A * w;
AF_final_2D = reshape(abs(AF_final), P_grid+1, Q_grid+1);
% 归一化到 0 dB
max_amp = max(AF_final_2D(:));
AF_db = 20*log10(AF_final_2D / max_amp);

%%  结果可视化
figure('Position', [100, 100, 1200, 500]);

% 1. 阵元分布图
subplot(1,3,1);
active_idx = find(abs(w) > 1e-2);
scatter(x_n(active_idx), y_n(active_idx), 36, abs(w(active_idx)), 'filled');
title(sprintf('固定阵元分布 (N=%d)', length(active_idx)));
xlabel('x (\lambda)'); ylabel('y (\lambda)');
axis equal; colorbar;

% 2. 方向图 (二维)
subplot(1,3,2);
imagesc(fhi_deg, theta_deg, AF_db);
set(gca,'YDir','normal') 
caxis([-40, 0]); 
title('优化后的方向图 (dB)');
xlabel('\phi (方位角) [Deg]'); ylabel('\theta (俯仰角) [Deg]');
colorbar;

% 3. 迭代收敛过程
subplot(1,3,3);
yyaxis left;
plot(1:L_iter, fit_errors, 'LineWidth', 2, 'Color', 'b');
ylabel('拟合误差 ');
yyaxis right;
plot(1:L_iter, sparsity_counts, 'LineWidth', 2, 'Color', 'r', 'LineStyle', '--');
ylabel('激活阵元数');
title('ADMM 收敛过程');
xlabel('迭代次数');
grid on;


%% ② 增加方向维和俯仰维两个方向上的切片显示
figure('Position', [100, 100, 1000, 400]);

% --- 方位维切片 (Theta 固定，扫 Phi) ---
subplot(1,2,1);
theta_slice_deg = theta0_deg;
[~, row_idx]   = min(abs(theta_deg - theta_slice_deg));
AF_slice_db    = AF_db(row_idx,:);          % 已归一化到 0 dB

plot(fhi_deg, AF_slice_db, 'LineWidth', 2); hold on;

% 旁瓣峰值检测
[pkVal, pkLoc] = findpeaks(AF_slice_db, fhi_deg, ...
                           'MinPeakHeight',-50, ...
                           'MinPeakProminence',4);
isMain         = pkVal > -1;                % 去掉 0 dB 附近主瓣
pkVal(isMain)  = [];  pkLoc(isMain) = [];
[sll_max,idx]  = max(pkVal);                % 最高旁瓣
yline(sll_max, 'r--', sprintf('SLL: %.2f dB', sll_max));

ylim([-50 5]); xlim([min(fhi_deg) max(fhi_deg)]); grid on;
title(sprintf('方位角切片 (\\theta = %.1f\\circ)', theta_deg(row_idx)));
xlabel('\phi (方位角) [Deg]'); ylabel('幅度 (dB)');

% --- 俯仰维切片 (Phi 固定，扫 Theta) ---
subplot(1,2,2);
fhi_slice_deg = fhi0_deg;
[~, col_idx]    = min(abs(fhi_deg - fhi_slice_deg));
AF_slice_db_phi = AF_db(:,col_idx);         % 列向量

plot(theta_deg, AF_slice_db_phi, 'LineWidth', 2, 'Color', 'g'); hold on;

% 旁瓣峰值检测
[pkVal, pkLoc] = findpeaks(AF_slice_db_phi, theta_deg, ...
                           'MinPeakHeight',-50, ...
                           'MinPeakProminence',4);
isMain         = pkVal > -1;
pkVal(isMain)  = [];  pkLoc(isMain) = [];
[sll_max,idx]  = max(pkVal);
yline(sll_max, 'r--', sprintf('SLL: %.2f dB', sll_max));

ylim([-50 5]); xlim([min(theta_deg) max(theta_deg)]); grid on;
title(sprintf('俯仰角切片 (\\phi = %.1f\\circ)', fhi_deg(col_idx)));
xlabel('\\theta (俯仰角) [Deg]'); ylabel('幅度 (dB)');
%% 增加方向图的二维坐标立体显示 (Z轴为dB值)
figure;

% 确保 THETA_GRID 和 FHI_GRID 是正确的二维网格
% THETA_GRID 范围是 0 到 180 度 (矩阵行)
% FHI_GRID 范围是 0 到 180 度 (矩阵列)
[FHI_3D_PLOT, THETA_3D_PLOT] = meshgrid(fhi_deg, theta_deg); 

% AF_db 是 P_grid+1 行 x Q_grid+1 列，维度与 THETA_3D_PLOT 匹配
AF_db_surface = AF_db;

% 使用 surf 函数进行立体显示
surf(FHI_3D_PLOT, THETA_3D_PLOT, AF_db_surface, 'EdgeColor', 'none'); 
colormap jet; 
colorbar;
% 设置 Z 轴的显示范围 (通常从-40dB到0dB)
zlim([-40, 0]); 
% 设置观察角度，提供立体感
view(45, 45); 

title('方向图立体显示 (角度域, dB)');
xlabel('\phi (方位角) [Deg]'); 
ylabel('\theta (俯仰角) [Deg]'); 
zlabel('幅度 (dB)');
grid on;

%% 显示全程序用时
elapsedTime = toc; % 停止计时器
fprintf('程序运行总用时: %.4f 秒\n', elapsedTime);