%% ============================================================
%  大规模平面稀疏阵列设计（ADMM + CVX 实现框架）ADMM——8——3
%ADMM_best程序加入其他旁瓣的比较
%修改后的程序改3
% =============================================================
%思路是三个程序的参数应保持一致
%==============================================================
%  gemini修正内容：ADMM变量差值累加、量级归一化、更新步长
%gemini再改：移除CVX改用解析解、修正梯度方向、增加数值保护
%  gemini再改：先固定位置优化权重(Warm Start)，再联合优化
%gemini改5
%修改后最好的版本
% =============================================================
%改为32*32的阵列，改为三维显示，阵元过于稀疏了
%gemini改方向图显示，改过于稀疏，改为2阶pade模型，引入信任域
%=============================================================
clc; clear; close all;
tic;

%% 1. 参数设置
lambda = 1;
k = 2*pi/lambda;
L_iter = 50;            
SLL_limit_dB = -25;
SLL_limit = 10^(SLL_limit_dB/20);

% 信任域参数
delta_d = 0.05 * lambda; 
delta_w = 0.2;           
TR_max_d = 0.1 * lambda;

%% 2. 目标网格与指向
P_grid = 45; Q_grid = 45;
theta_deg = linspace(0, 180, P_grid);
phi_deg = linspace(0, 180, Q_grid);
[PHI_G, THETA_G] = meshgrid(deg2rad(phi_deg), deg2rad(theta_deg));
U = sin(THETA_G(:)) .* cos(PHI_G(:));
V = sin(THETA_G(:)) .* sin(PHI_G(:));
u0 = 0; v0 = 1; 
side_lobe_mask = sqrt((U-u0).^2 + (V-v0).^2) > 0.18; 
U_s = U(side_lobe_mask);
V_s = V(side_lobe_mask);

%% 3. 初始化 (32x32 满阵)
Grid_Size = 32;
Spacing = 0.5 * lambda;
[X_G, Y_G] = meshgrid((-(Grid_Size-1)/2:(Grid_Size-1)/2)*Spacing);
x_n = X_G(:); y_n = Y_G(:);
N = length(x_n);
w = ones(N, 1) / N; 
W_reweight = ones(N, 1); 

history_sparsity = zeros(L_iter, 1);
history_sll = zeros(L_iter, 1);

fprintf('开始优化 (已修正维度匹配问题)...\n');

%% 4. 优化迭代
for iter = 1:L_iter
    % 当前流形
    A_c = exp(1j * k * (u0 * x_n + v0 * y_n)); 
    % A_s 维度: [M_s x N]
    A_s = exp(1j * k * (U_s * x_n' + V_s * y_n')); 
    
    % --- CVX 子问题 ---
    cvx_begin quiet
        variable dw(N) complex
        variable dd_x(N)
        variable dd_y(N)
        
        % 目标函数: 加权一范数
        minimize( norm( W_reweight .* (w + dw), 1 ) )
        
        subject to
            % 1. 主瓣约束
            real(A_c' * (w + dw)) >= 1.0;
            imag(A_c' * (w + dw)) == 0;
            
            % 2. 旁瓣约束 (线性化/二阶近似部分)
            % 正确的维度处理：
            % 每个阵元的贡献是: w_n * exp(jk*...) * (1 + jk*u*ddx + ...)
            % 我们构造对应的项：
            term_w = A_s * (w + dw);
            % 位置变化项需要对每个阵元单独操作，再求和
            % 使用 diag(w)*dd_x 会导致巨大的中间矩阵，推荐以下写法：
            term_dx = (A_s .* (U_s * (1j * k * dd_x'))) * w;
            term_dy = (A_s .* (V_s * (1j * k * dd_y'))) * w;
            
            abs( term_w + term_dx + term_dy ) <= SLL_limit;
            
            % 3. 信任域与物理约束
            norm(dw, 2) <= delta_w;
            norm(dd_x, Inf) <= delta_d;
            norm(dd_y, Inf) <= delta_d;
    cvx_end

    if strcmp(cvx_status, 'Failed') || strcmp(cvx_status, 'Infeasible')
        delta_d = delta_d * 0.5;
        continue;
    end
    
    % --- 更新变量 ---
    w = w + dw;
    x_n = x_n + dd_x;
    y_n = y_n + dd_y;
    
    % --- 强效重加权 (确保阵元数下降) ---
    W_reweight = 1 ./ (abs(w) + 1e-4); 
    
    % 统计
    active_idx = abs(w) > 0.01 * max(abs(w));
    history_sparsity(iter) = sum(active_idx);
    current_sll = 20*log10(max(abs(A_s * w)));
    history_sll(iter) = current_sll;
    
    fprintf('Iter %d | 阵元: %d | SLL: %.2f dB | delta_d: %.1e\n', ...
            iter, history_sparsity(iter), current_sll, delta_d);
        
    % 信任域半径调整
    if current_sll < SLL_limit * 1.1
        delta_d = min(delta_d * 1.1, TR_max_d);
    else
        delta_d = delta_d * 0.7;
    end
end

%% 5. 绘图
A_final = exp(1j * k * (U * x_n' + V * y_n'));
AF_final = reshape(abs(A_final * w), P_grid, Q_grid);
AF_final = AF_final / max(AF_final(:));
AF_dB = 20*log10(AF_final + 1e-6);



figure('Color','w','Name','稀疏优化结果');
subplot(1,2,1);
scatter(x_n(active_idx), y_n(active_idx), 20, abs(w(active_idx)), 'filled');
axis equal; grid on; title(['阵元分布 (剩余: ', num2str(history_sparsity(end)), ')']);

subplot(1,2,2);
plot(history_sparsity(1:iter), 'LineWidth', 2);
grid on; xlabel('Iteration'); ylabel('Number of Active Elements');
title('阵元数下降趋势');

figure('Color','w','Name','方向图切片');
subplot(1,2,1);
plot(theta_deg, AF_dB(:, round(Q_grid/2)), 'LineWidth', 2);
hold on; yline(SLL_limit_dB, 'r--');
grid on; title('纵向切片');

subplot(1,2,2);
plot(phi_deg, AF_dB(round(P_grid/2), :), 'LineWidth', 2);
hold on; yline(SLL_limit_dB, 'r--');
grid on; title('横向切片');

toc;