%% ADMM + CVX 修正版：平顶波束（含稳定性修正）
% 说明：相对于你给的版本，关键变化：
%  - 在 CVX 中加主瓣中心等式 AF(center)==1（避免 w=0）
%  - 在 CVX 目标里加入主瓣 L2 拟合项（beta_fit）
%  - 重加权用当前 w（g_weights = 1/(|w|+eps)）
%  - 位置更新加 max_move 和梯度归一化+局部投影，防止剧烈扰动
%  - gamma 调小以避免过度稀疏化
clc; clear; close all;
tic;

%% parameters
lambda = 1; k = 2*pi/lambda;
d_min = 0.5*lambda;
L_iter = 50;

% beam constraints
SLL_dB = -20; R_SL = 10^(SLL_dB/20);
R_P = 1.05;

% ADMM / sparse params (tuned)
rho = 5;             % ADMM coupling
gamma = 1e-4;        % 稀疏正则化 (减小以免过度阉割)
epsilon = 1e-4;      % 重加权防零
beta_fit = 1.0;      % L2 拟合权重 in CVX

% position update params
step_size_pos = 5e-4;  % 减小位置步长以稳定
eta = 5;               % repulsive weight
max_move = 0.1 * d_min; % 每次位置最大移动（物理约束）
grad_clip = 1.0;

% grid for AF evaluation (适度减小以加快)
P_grid = 90; Q_grid = 90;
theta_deg = linspace(0,180,P_grid+1);
fhi_deg = linspace(0,180,Q_grid+1);
[PHI, TH] = meshgrid(deg2rad(fhi_deg), deg2rad(theta_deg));
THETA_VEC = TH(:); FHI_VEC = PHI(:);
M = numel(THETA_VEC);
U = sin(THETA_VEC).*cos(FHI_VEC);
V = sin(THETA_VEC).*sin(FHI_VEC);

% flat-top target region (u,v)
theta0_deg = 90; fhi0_deg = 90;
u0 = sin(deg2rad(theta0_deg))*cos(deg2rad(fhi0_deg));
v0 = sin(deg2rad(theta0_deg))*sin(deg2rad(fhi0_deg));
target_radius = 0.15;
dist_from_main = sqrt((U-u0).^2 + (V-v0).^2);
main_lobe_idx = dist_from_main <= target_radius;
sidelobe_idx = ~main_lobe_idx;
D = zeros(M,1); D(main_lobe_idx)=1;

%% array init (moderate size)
Grid_Size = 12;
Spacing = d_min;
coords_1D = linspace(-(Grid_Size-1)/2*Spacing, (Grid_Size-1)/2*Spacing, Grid_Size);
[X_GRID, Y_GRID] = meshgrid(coords_1D, coords_1D);
x_n = X_GRID(:); y_n = Y_GRID(:);
N = length(x_n);

% ADMM variables
w = ones(N,1); s = w; u_dual = zeros(N,1);

% storage
W_save = zeros(L_iter,N);
xn_save = zeros(L_iter,N);
yn_save = zeros(L_iter,N);
fit_errors = zeros(L_iter,1);
sparsity_counts = zeros(L_iter,1);
SLLs = zeros(L_iter,1);

% center index to enforce AF(center)==1
[~, idx_center] = min(dist_from_main);

%% main loop
for iter = 1:L_iter
    % build A
    Phase_Term = U * x_n' + V * y_n';
    A = exp(1j * k * Phase_Term);  % M x N
    A_ML = A(main_lobe_idx, :);
    A_SL = A(sidelobe_idx, :);
    D_ML = D(main_lobe_idx);
    
    % --- CVX subproblem: update w_new (complex) ---
    % minimize beta*||A_ML*w - D_ML||^2 + (rho/2)*||w - s + u||^2
    % s.t. abs(A_SL*w) <= R_SL, abs(A_ML*w) <= R_P, AF(center)==1
    cvx_begin quiet
        variable w_new(N) complex
        minimize( beta_fit * sum_square_abs(A_ML * w_new - D_ML) + (rho/2) * sum_square_abs(w_new - s + u_dual) )
        subject to
            abs(A_SL * w_new) <= R_SL;
            abs(A_ML * w_new) <= R_P;
            A(idx_center,:) * w_new == 1;
    cvx_end
    % if cvx failed, keep previous w
    if ~exist('w_new','var') || any(isnan(w_new))
        warning('CVX failed or produced NaN; keep old w');
        w_new = w;
    end
    w = w_new;
    
    % --- sparse update for s (reweighted soft-thresholding) ---
    g_weights = 1 ./ (abs(w) + epsilon);  % based on current w
    v_temp = w + u_dual;
    threshold = (gamma .* g_weights) / rho;
    v_abs = abs(v_temp);
    v_phase = v_temp ./ (v_abs + (v_abs==0));
    s = v_phase .* max(v_abs - threshold, 0);
    % ensure center element(s) not forcibly zeroed: keep elements contributing to center
    % prevent zeroing those that contribute strongly to AF center
    center_row = A(idx_center, :);
    [~, main_contrib_idx] = sort(abs(center_row.' .* w),'descend');
    % keep top K contributors (K small) from being zeroed by setting lower threshold
    Kkeep = min(3, N);
    keep_idx = main_contrib_idx(1:Kkeep);
    s(keep_idx) = w(keep_idx);  % protect these entries to maintain AF(center)
    
    % --- dual update ---
    u_dual = u_dual + (w - s);
    
    % --- position update (vectorized gradient descent with constraints) ---
    AF_current = A * w;
    e = AF_current - D;  % complex residual
    C_u = U .* conj(e); C_v = V .* conj(e);
    sum_terms_x = A.' * C_u; sum_terms_y = A.' * C_v;
    grad_x_pattern = 2 * real(1j * k * (w .* sum_terms_x));
    grad_y_pattern = 2 * real(1j * k * (w .* sum_terms_y));
    
    % repulsive gradient
    grad_dist_x = zeros(N,1); grad_dist_y = zeros(N,1);
    for i = 1:N
        dx = x_n(i) - x_n;
        dy = y_n(i) - y_n;
        dist = sqrt(dx.^2 + dy.^2) + 1e-12;
        mask = (dist < d_min) & (dist > 1e-9);
        if any(mask)
            dirx = dx(mask) ./ dist(mask);
            diry = dy(mask) ./ dist(mask);
            force = (d_min - dist(mask));
            grad_dist_x(i) = grad_dist_x(i) + sum(force .* dirx);
            grad_dist_y(i) = grad_dist_y(i) + sum(force .* diry);
        end
    end
    
    grad_x = grad_x_pattern + eta * grad_dist_x;
    grad_y = grad_y_pattern + eta * grad_dist_y;
    % normalize global magnitude
    maxg = max(1, max(abs([grad_x; grad_y])));
    grad_x = grad_x / maxg; grad_y = grad_y / maxg;
    % compute proposed moves and clip by max_move
    dx_prop = - step_size_pos * grad_x;
    dy_prop = - step_size_pos * grad_y;
    % clip each move
    dx_prop = max(min(dx_prop, max_move), -max_move);
    dy_prop = max(min(dy_prop, max_move), -max_move);
    % update coordinates
    x_n = x_n + dx_prop;
    y_n = y_n + dy_prop;
    
    % projection: enforce pairwise min spacing (symmetric push)
    for i = 1:N
        for j = i+1:N
            dx = x_n(i) - x_n(j); dy = y_n(i) - y_n(j);
            dist = sqrt(dx^2 + dy^2) + 1e-12;
            if dist < d_min
                overlap = (d_min - dist)/2;
                px = overlap * (dx/dist);
                py = overlap * (dy/dist);
                x_n(i) = x_n(i) + px; y_n(i) = y_n(i) + py;
                x_n(j) = x_n(j) - px; y_n(j) = y_n(j) - py;
            end
        end
    end
    
    % diagnostics
    AF_mag = abs(AF_current);
    AF_mag_norm = AF_mag / (max(AF_mag(main_lobe_idx)) + 1e-12);
    fit_err_ml = norm(AF_mag_norm(main_lobe_idx) - 1)^2;
    fit_err_sl = norm(AF_mag_norm(sidelobe_idx))^2;
    fit_error = fit_err_ml + fit_err_sl;
    sparsity_count = sum(abs(w) > 1e-3);
    SLL_current = max(AF_mag_norm(sidelobe_idx));
    fprintf('Iter %d: fit_err=%.4e, fit_ml=%.4e, active=%d, SLL=%.2f dB\n', ...
        iter, fit_error, fit_err_ml, sparsity_count, 20*log10(SLL_current+1e-12));
    
    % store
    W_save(iter,:) = w.';
    xn_save(iter,:) = x_n.';
    yn_save(iter,:) = y_n.';
    fit_errors(iter) = fit_error;
    sparsity_counts(iter) = sparsity_count;
    SLLs(iter) = 20*log10(SLL_current+1e-12);
end

%% visualize
figure;
subplot(1,2,1);
active_idx = find(abs(w) > 1e-3);
scatter(x_n(active_idx), y_n(active_idx), 40, abs(w(active_idx)), 'filled');
axis equal; colorbar; title(sprintf('Active elements: %d', numel(active_idx)));
xlabel('x(\lambda)'); ylabel('y(\lambda)');

subplot(1,2,2);
AF_final = abs(reshape(A * w, numel(theta_deg), numel(fhi_deg)));
AF_db = 20*log10(AF_final / max(AF_final(:)));
imagesc(fhi_deg, theta_deg, AF_db); set(gca,'YDir','normal'); caxis([-50,0]);
xlabel('\phi (deg)'); ylabel('\theta (deg)');
title('AF (dB)');

figure;
yyaxis left; plot(1:L_iter, fit_errors, '-b','LineWidth',1.2); ylabel('fit err');
yyaxis right; plot(1:L_iter, sparsity_counts, '--r','LineWidth',1.2); ylabel('active elements');
xlabel('iteration'); grid on;

elapsed = toc;
fprintf('Total time: %.2f s\n', elapsed);
